local _, Addon = ...

-- [泰坦時光服 3.80.2 修復 titan1]
-- UnitClassBase 係 9.0 先引入嘅現代 API；3.x 客戶端一般冇。
-- 原版直接喺第 2 行呼叫，一旦係 nil 成個檔即刻斷，連後面都唔會跑。
-- 而家改成：有就用，冇就退回經典 UnitClass 取英文 class token。
local CLASS
if type(UnitClassBase) == 'function' then
    CLASS = UnitClassBase('player')
end
if not CLASS then
    CLASS = select(2, UnitClass('player'))
end

local function hide(...)
    for i = 1, select('#', ...) do
        local frame = select(i, ...)

        if frame then
            frame:Hide()
            -- [泰坦時光服修復 titan1] ShadowUIParent 未建立時唔好 SetParent(nil)
            if Addon and Addon.ShadowUIParent then
                frame:SetParent(Addon.ShadowUIParent)
            end
            frame.ignoreFramePositionManager = true

            -- with 8.2, there's more restrictions on frame anchoring if something
            -- happens to be attached to a restricted frame. This causes issues with
            -- moving the action bars around, so we perform a clear all points to avoid
            -- some frame dependency issues
            -- we then follow it up with a SetPoint to handle the cases of bits of the
            -- UI code assuming that this element has a position
            frame:ClearAllPoints()
            frame:SetPoint('CENTER')
        end
    end
end

-- disables override bar transition animations
local function disableSlideOutAnimations(...)
    for i = 1, select('#', ...) do
        local frame = select(i, ...)

        if frame and frame.slideOut then
            local animation = (frame.slideOut:GetAnimations())
            if animation then
                animation:SetOffset(0, 0)
            end
        end
    end
end

hide(
    ActionBarDownButton,
    ActionBarUpButton,
    MainMenuBarPerformanceBarFrame,
    MicroButtonAndBagsBar,
    MultiBarBottomLeft,
    MultiBarBottomRight,
    MultiBarLeft,
    MultiBarRight,
    StanceBarFrame
)

if not (CLASS == 'SHAMAN' and Addon:IsGameType('wrath')) then
    hide(MultiCastActionBarFrame)
end

disableSlideOutAnimations(
    MainMenuBar,
    MultiBarLeft,
    MultiBarRight,
    OverrideActionBar,
    MultiCastActionBarFrame
)

-- we don't completely disable the main menu bar, as there's some logic
-- dependent on it being visible
if MainMenuBar then
    MainMenuBar:EnableMouse(false)

    -- the main menu bar is responsible for updating the micro buttons
    -- so we don't disable all events for it
    MainMenuBar:UnregisterEvent('ACTIONBAR_PAGE_CHANGED')
    MainMenuBar:UnregisterEvent('PLAYER_ENTERING_WORLD')
    MainMenuBar:UnregisterEvent('DISPLAY_SIZE_CHANGED')
    MainMenuBar:UnregisterEvent('UI_SCALE_CHANGED')
end

-- don't hide the art frame, as the multi action bars are dependent on GetLeft
-- or similar calls returning a value
if MainMenuBarArtFrame then
    MainMenuBarArtFrame:SetAlpha(0)
end

-- don't reparent the tracking manager, as it assumes its parent has a callback
if StatusTrackingBarManager then
    StatusTrackingBarManager:UnregisterAllEvents()
    StatusTrackingBarManager:Hide()
end

if MainMenuExpBar then
    MainMenuExpBar:UnregisterAllEvents()
    hide(MainMenuExpBar)
end

if ReputationWatchBar then
    ReputationWatchBar:UnregisterAllEvents()
    hide(ReputationWatchBar)

    -- [泰坦時光服修復 titan1] 函數唔存在時 hooksecurefunc 會報錯
    if type(_G.MainMenuBar_UpdateExperienceBars) == 'function' then
        hooksecurefunc(
            'MainMenuBar_UpdateExperienceBars',
            function()
                ReputationWatchBar:Hide()
            end
        )
    end
end

if MainMenuBarMaxLevelBar then
    MainMenuBarMaxLevelBar:UnregisterAllEvents()
    hide(MainMenuBarMaxLevelBar)
end

if VerticalMultiBarsContainer then
    VerticalMultiBarsContainer:UnregisterAllEvents()

    hide(VerticalMultiBarsContainer)

    -- a hack to preserve the multi action bar spacing behavior for the quest log
    -- [泰坦時光服修復 titan1] 函數唔存在時 hooksecurefunc 會報錯
    if type(_G.MultiActionBar_Update) ~= 'function' then
        return
    end

    hooksecurefunc(
        'MultiActionBar_Update',
        function()
            local width = 0
            local showLeft = SHOW_MULTI_ACTIONBAR_3
            local showRight = SHOW_MULTI_ACTIONBAR_4
            local stack = GetCVarBool('multiBarRightVerticalLayout')

            if showLeft then
                width = width + VERTICAL_MULTI_BAR_WIDTH
            end

            if showRight and not stack then
                width = width + VERTICAL_MULTI_BAR_WIDTH
            end

            VerticalMultiBarsContainer:SetWidth(width)
        end
    )
end

-- [泰坦時光服 3.80.2 修復 titan1]
-- 以下常量喺部分客戶端為 nil，原版直接拿去做算術／迴圈會報
-- "attempt to perform arithmetic on a nil value" / "'for' limit must be a number"。
if NUM_ACTIONBAR_BUTTONS == nil then NUM_ACTIONBAR_BUTTONS = 12 end
if VERTICAL_MULTI_BAR_WIDTH == nil then VERTICAL_MULTI_BAR_WIDTH = 33 end

-- set the stock action buttons to hidden by default
--
-- [泰坦時光服修復 titan9] ★緊急還原★
--
-- 我喺 titan8 做咗兩樣嘢，兩樣都錯，呢度全部撤銷：
--   1. button:UnregisterAllEvents()
--      -> 會令 Dominos 收唔到 ACTIONBAR_PAGE_CHANGED 等事件，
--         切姿態 / 切動作條頁全部失靈。
--   2. button:HookScript("OnShow", function(self) self:Hide() end)
--      -> ★呢句就係令動作條消失嘅元兇★
--
-- 錯嘅原因（重要，記低）：
--   我以為 ActionButton1..12 係「暴雪原廠、Dominos 隱形唔用」嘅掣。
--   但 Dominos【經典版】係直接復用 ActionButton1..12 做自己嘅掣，
--   唔係另開 DominosActionButton。
--   所以一 Hide 佢，Dominos 想 Show 就即刻被收皮 -> 成條動作條變透明。
--   報錯 'ActionButton1:SetShown()' 來自
--   ActionBar.lua:206 UpdateShownButtons，
--   正正證實 ActionButton1 係顯示緊、由 ActionBar 管理緊嘅。
--
-- 而家還原做原版：SetAttribute('statehidden', true) + Hide()。
-- 淨係保留【淨係隱形掣先跳過】嘅 UpdatePressAndHoldAction 覆蓋 ——
-- 顯示緊嘅掣完全照原邏輯行，零影響，唔會再搞冇動作條。
local function TitanNeuterPressAndHold(button)
    if (button == nil) or (button.TitanPressAndHoldNeutered) then return end
    local orig = button.UpdatePressAndHoldAction
    if (type(orig) ~= "function") then return end
    button.UpdatePressAndHoldAction = function(self, ...)
        -- [titan10] 隱形掣：冇人睇，直接唔做（同 titan9 一樣）
        if not self:IsVisible() then
            return
        end
        -- [titan10] ★核心改動★
        -- 戰鬥中就【唔好做】，直接 return。
        --
        -- 點解呢個係「零影響」？
        --   報錯係 ADDON_ACTION_BLOCKED —— 個 SetAttribute
        --   已經【被客戶端擋咗、根本冇執行到】。
        --   即係無論我跳唔跳，結果都係「冇 set 到」。
        --   我淨係【慳返個報錯】，行為完全一致。
        --
        -- 亦解釋咗點解 titan9 冇用：
        --   titan9 淨係「隱形先跳過」，但 ActionButton1 係顯示緊
        --   （AB1: true，Dominos 經典版直接復用佢），所以冇跳到。
        --
        -- 戰鬥外照常執行 -> pressAndHoldAction 正常設定好，
        -- 入戰鬥嗰陣值已經係啱嘅，唔會影響手感。
        if (InCombatLockdown ~= nil) and InCombatLockdown() then
            return
        end
        return orig(self, ...)
    end
    button.TitanPressAndHoldNeutered = true
end

-- [泰坦時光服修復 titan11]
-- 處理另一條 BLOCKED：
--   [ADDON_ACTION_BLOCKED] 插件 'Dominos'
--   嘗試調用保護功能 'ActionButton1:SetShown()'
--   ActionBar.lua:206 UpdateShownButtons
--     -> ActionButton.lua:548 UpdateAction -> :975 OnEvent
--
-- 同一個道理：報錯係 BLOCKED，即係個 SetShown【已經被客戶端擋咗、
-- 根本冇執行到】。無論我跳唔跳，結果都係「冇改到顯示狀態」。
-- 所以我淨係慳返個報錯，行為完全一致。
--
-- 點解可以成個函數跳過而唔係逐個掣？
--   UpdateShownButtons 係對【成條 bar 嘅掣】做 SetShown，
--   而呢條 bar 嘅掣全部都被 disableActionButton 掂過（tainted），
--   所以喺戰鬥中【每一個】都會被擋。
--   成個函數跳過 == 逐個被擋，結果一樣。
--
-- 戰鬥外照常執行 -> 入戰鬥嗰陣掣嘅顯示狀態已經係啱嘅。
local function TitanNeuterUpdateShown(bar)
    if (bar == nil) or (bar.TitanUpdateShownNeutered) then return end
    local orig = bar.UpdateShownButtons
    if (type(orig) ~= "function") then return end
    bar.UpdateShownButtons = function(self, ...)
        if (InCombatLockdown ~= nil) and InCombatLockdown() then
            return
        end
        return orig(self, ...)
    end
    bar.TitanUpdateShownNeutered = true
end

local function disableActionButton(buttonName)
    local button = _G[buttonName]
    if button then
        button:SetAttribute('statehidden', true)
        button:Hide()
        -- [titan9] 淨係加呢個：隱形嘅先跳過，顯示緊嘅完全照舊
        TitanNeuterPressAndHold(button)
    else
        Addon:Printf('Action Button %q could not be found', buttonName)
    end
end

-- [titan11] 對所有動作條框架套用 UpdateShownButtons 戰鬥中跳過
for _, barName in ipairs({
    'MainActionBar',
    'MultiBarBottomLeft',
    'MultiBarBottomRight',
    'MultiBarLeft',
    'MultiBarRight',
    'MultiBar5',
    'MultiBar6',
    'MultiBar7',
    'BonusActionBarFrame',
    'StanceBar',
    'StanceBarFrame',
}) do
    TitanNeuterUpdateShown(_G[barName])
end

-- [泰坦時光服修復 titan12] ★通用 BLOCKED 封鎖（唔使再逐個掣嚟改）★
--
-- 背景：之前一條條咁封，永遠有下一個：
--   ActionButton1 -> MultiBarBottomLeftButton11 -> ActionButton1:SetShown
--   -> OverrideActionBarButton1 -> ...
-- 因為全遊戲有幾百個動作掣，逐個認名係死路。
--
-- 做法：唔認名，認【特徵】
--   有 UpdatePressAndHoldAction 嘅 = 動作掣     -> 全部包住
--   有 UpdateShownButtons       嘅 = 動作條框架 -> 全部包住
--   OverrideActionBarButton* / VehicleMenuBar* 嗰啲全部自動中。
--
-- 零風險（重點）：
--   BLOCKED = 個呼叫【已經被客戶端擋咗、根本冇執行到】。
--   「我跳過佢」同「佢被擋」結果完全一樣 -> 行為零改變。
--   戰鬥外照常執行，入戰鬥嗰陣值已經係啱嘅。
--   冇 Hide / 冇 UnregisterAllEvents / 冇 OnShow hook
--   （titan8 就係死喺呢三樣，永久移除）。
--
-- 三層掃描 + 載入後重掃（遲建立嘅掣都封到）。
local TitanBlockedTotal = 0

local function TitanInCombat()
    return (InCombatLockdown ~= nil) and InCombatLockdown()
end

local function TitanWrapOne(v)
    if (type(v) ~= 'table') or (v.TitanWrapped) then return end
    -- rawget 避免觸發 __index（有啲插件會俾 _G 加 metatable）
    if (type(rawget(v, 'UpdatePressAndHoldAction')) == 'function') then
        local orig = v.UpdatePressAndHoldAction
        v.UpdatePressAndHoldAction = function(self, ...)
            if TitanInCombat() then return end
            return orig(self, ...)
        end
        v.TitanWrapped = true
        TitanBlockedTotal = TitanBlockedTotal + 1
    end
    if (type(rawget(v, 'UpdateShownButtons')) == 'function') then
        local orig = v.UpdateShownButtons
        v.UpdateShownButtons = function(self, ...)
            if TitanInCombat() then return end
            return orig(self, ...)
        end
        v.TitanWrapped = true
        TitanBlockedTotal = TitanBlockedTotal + 1
    end
end

local TITAN_PREFIXES = {
    'ActionButton', 'BonusActionButton',
    'MultiBarBottomLeftButton', 'MultiBarBottomRightButton',
    'MultiBarRightButton', 'MultiBarLeftButton',
    'MultiBar5Button', 'MultiBar6Button', 'MultiBar7Button',
    'OverrideActionBarButton', 'StanceButton', 'PetActionButton',
    'PossessButton', 'DominosPossessButton',
    'ExtraActionButton', 'ZoneAbilityButton',
    'VehicleMenuBarActionButton',
}
local TITAN_BARS = {
    'MainActionBar', 'BonusActionBarFrame',
    'MultiBarBottomLeft', 'MultiBarBottomRight',
    'MultiBarLeft', 'MultiBarRight',
    'MultiBar5', 'MultiBar6', 'MultiBar7',
    'OverrideActionBar', 'StanceBar', 'StanceBarFrame',
    'PetActionBar', 'PetActionBarFrame',
    'PossessBar', 'PossessBarFrame',
}

local function TitanScanAndWrap()
    pcall(function()
        for _, v in pairs(_G) do
            TitanWrapOne(v)
        end
    end)
    for _, p in ipairs(TITAN_PREFIXES) do
        for i = 1, 24 do
            local b = _G[p .. i]
            if (b == nil) then break end
            TitanWrapOne(b)
        end
    end
    for _, n in ipairs(TITAN_BARS) do
        TitanWrapOne(_G[n])
    end
end

local TitanScanFrame = CreateFrame('Frame')
TitanScanFrame:RegisterEvent('PLAYER_LOGIN')
TitanScanFrame:SetScript('OnEvent', function()
    TitanScanAndWrap()
    local delays = { 0.5, 2, 5, 10 }
    if (C_Timer ~= nil) and (C_Timer.After ~= nil) then
        for _, d in ipairs(delays) do
            C_Timer.After(d, TitanScanAndWrap)
        end
    else
        -- C_Timer 冇就用 OnUpdate 兜底
        local acc, n = 0, 0
        TitanScanFrame:SetScript('OnUpdate', function(_, e)
            acc = acc + e
            if (acc >= 2) then
                acc = 0
                n = n + 1
                TitanScanAndWrap()
                if (n >= 5) then TitanScanFrame:SetScript('OnUpdate', nil) end
            end
        end)
    end
end)

SLASH_TITANBLOCKED1 = '/dtfa'
SlashCmdList['TITANBLOCKED'] = function()
    local before = TitanBlockedTotal
    TitanScanAndWrap()
    print(('|cff66ccffDominos titan12|r  已封 %d 個（本次新增 %d）')
        :format(TitanBlockedTotal, TitanBlockedTotal - before))
end

for id = 1, NUM_ACTIONBAR_BUTTONS do
    disableActionButton(('ActionButton%d'):format(id))
    disableActionButton(('MultiBarRightButton%d'):format(id))
    disableActionButton(('MultiBarLeftButton%d'):format(id))
    disableActionButton(('MultiBarBottomRightButton%d'):format(id))
    disableActionButton(('MultiBarBottomLeftButton%d'):format(id))
end

-- container offsets are a bit broken when using Dominos for action bars in 1.15.4
-- this prevents the UIParent position manager from updating them, dynamically
-- [泰坦時光服 3.80.2 修復 titan1] ★呢個就係原本報錯嗰行★
-- UIPARENT_MANAGED_FRAME_POSITIONS 喺泰坦時光服客戶端為 nil，
-- 對 nil 做索引賦值會報
-- "attempt to perform indexed assignment on global
--  'UIPARENT_MANAGED_FRAME_POSITIONS' (a nil value)"
-- 並中斷成個 Dominos 載入流程。
-- 呢個表只係用嚟停用背包偏移自動調整，唔存在即係客戶端冇呢個機制，
-- 直接跳過就安全；存在就照原邏輯清掉兩個欄位。
if type(UIPARENT_MANAGED_FRAME_POSITIONS) == 'table' then
    UIPARENT_MANAGED_FRAME_POSITIONS.CONTAINER_OFFSET_X = nil
    UIPARENT_MANAGED_FRAME_POSITIONS.CONTAINER_OFFSET_Y = nil
end
