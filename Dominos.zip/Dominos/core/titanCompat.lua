-- ============================================================================
--  Dominos - Titan Classic (3.80.2 / WLK) compatibility shim
--  File: core\titanCompat.lua
--  Loaded right after Dominos.lua, before any bars/ module.
--
--  WHY THIS EXISTS
--  Dominos 11.4.5 targets the modern (Dragonflight+) client. The Titan
--  3.80.2 client is a HYBRID: it keeps some modern frames, renames others,
--  and drops the rest. This shim fills the gaps so every bars/ module loads
--  cleanly on ALL classes (this user plays every class).
--
--  Measured on this client:
--    UnitClassBase                     = true
--    CommunitiesFrame                  = true   (ListScrollFrame -> ScrollBox)
--    WardrobeCollectionFrame           = true   (ItemsCollectionFrame only)
--    StanceBar                         = true   (renamed from StanceBarFrame)
--    PetActionBar                      = true   (renamed from PetActionBarFrame)
--    MultiCastActionBarFrame           = true
--    RuneFrame / TotemFrame / ComboFrame = true
--    OverrideActionBar                 = true
--    BattlePetTooltip                  = false
--    EncounterJournalTooltip           = false
--    PossessBarFrame                   = false
--    UIPARENT_MANAGED_FRAME_POSITIONS  = false
--    Blizzard_InterfaceOptions         = MISSING
--
--  Everything here is a no-op on a normal retail client.
-- ============================================================================

local _, Addon = ...

--------------------------------------------------------------------------------
-- 1. MicroMenu  (menuBar.lua calls this at file scope -> would abort load)
--
-- WLK 3.x has no MicroMenu container; the micro buttons are standalone
-- globals parented to MainMenuBarArtFrame. Dominos' menuBar.lua does:
--     for _, buttonInfo in ipairs(MicroMenu:GenerateButtonInfos()) do
-- at the top level, so a nil MicroMenu kills the whole addon.
--------------------------------------------------------------------------------
if not MicroMenu then
    local WLK_MICRO_BUTTONS = {
        'CharacterMicroButton',
        'SpellbookMicroButton',
        'TalentMicroButton',
        'AchievementMicroButton',
        'QuestLogMicroButton',
        'SocialsMicroButton',
        'PVPMicroButton',
        'LFGMicroButton',
        'MainMenuMicroButton',
        'HelpMicroButton',
    }

    local shim = CreateFrame('Frame', 'DominosMicroMenuShim', UIParent)
    shim:SetSize(1, 1)
    shim:Show()

    shim.buttonInfos = {}

    function shim:GenerateButtonInfos()
        local infos = self.buttonInfos

        table.wipe(infos)

        for _, name in ipairs(WLK_MICRO_BUTTONS) do
            local button = _G[name]
            if button then
                infos[#infos + 1] = { button = button }
            end
        end

        return infos
    end

    -- menuBar.lua hooks this; harmless on the shim
    function shim:UpdateHelpTicketButtonAnchor() end

    MicroMenu = shim
end

--------------------------------------------------------------------------------
-- 2. Modern-only namespaces referenced unguarded by menuBar.lua
--------------------------------------------------------------------------------
if not C_StorePublic then
    C_StorePublic = {
        IsEnabled = function() return false end,
    }
end

if not C_GameRules then
    C_GameRules = {
        IsGameRuleActive = function() return false end,
    }
end

if not C_PetBattles then
    C_PetBattles = {
        IsInBattle = function() return false end,
    }
end

--------------------------------------------------------------------------------
-- 3. Action-button-count constant used by bar.lua (secure attribute)
--------------------------------------------------------------------------------
if NUM_ACTIONBAR_BUTTONS == nil then
    NUM_ACTIONBAR_BUTTONS = 12
end

if NUM_PET_ACTION_SLOTS == nil then
    NUM_PET_ACTION_SLOTS = 10
end

if NUM_BAG_SLOTS == nil then
    NUM_BAG_SLOTS = 4
end

--------------------------------------------------------------------------------
-- 4. Renamed frames: give Dominos the old names back as aliases
--    (harmless if the old name already exists)
--------------------------------------------------------------------------------
if StanceBarFrame == nil and StanceBar ~= nil then
    StanceBarFrame = StanceBar
end

if PetActionBarFrame == nil and PetActionBar ~= nil then
    PetActionBarFrame = PetActionBar
end

--------------------------------------------------------------------------------
-- 5. Safe accessor for the per-bar "actionButtons" tables.
--    On this client StanceBar / PetActionBar exist but their .actionButtons
--    may be nil, and  pairs(nil)  aborts the whole module.
--------------------------------------------------------------------------------
function Addon.TitanGetActionButtons(bar)
    if type(bar) ~= 'table' then
        return nil
    end

    local buttons = bar.actionButtons
    if type(buttons) ~= 'table' then
        return nil
    end

    return buttons
end

--------------------------------------------------------------------------------
-- 6. EventRegistry guard helper
--    bagBar.lua calls EventRegistry:UnregisterCallback(...) with only a
--    partial guard, and also has a typo (UnegisterFrameEventAndCallback).
--------------------------------------------------------------------------------
function Addon.TitanUnregisterCallback(target, event)
    if type(EventRegistry) ~= 'table' then
        return false
    end

    if type(EventRegistry.UnregisterCallback) ~= 'function' then
        return false
    end

    pcall(EventRegistry.UnregisterCallback, EventRegistry, event, target)
    return true
end
