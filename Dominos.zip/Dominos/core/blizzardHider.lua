local _, Addon = ...

local framesToHide = {
    "MainActionBar",
    "MultiBar5",
    "MultiBar6",
    "MultiBar7",
    "MultiBarBottomLeft",
    "MultiBarBottomRight",
    "MultiBarLeft",
    "MultiBarRight"
}

if not Addon:IsGameType('standard', "forever") then
    framesToHide[#framesToHide + 1] = "MainMenuBar"
    framesToHide[#framesToHide + 1] = "MainMenuBarArtFrame"
end

local keepEvents = {
    MainActionBar = true
}

-- [泰坦時光服修復 titan7] 斷根：ADDON_ACTION_BLOCKED
--
-- 原本嘅報錯：
--   [ADDON_ACTION_BLOCKED] 插件 'Dominos' 嘗試調用保護功能 'ActionButton1:SetAttribute()'
--   Blizzard_ActionBar/Shared/ActionButton.lua:521 UpdatePressAndHoldAction
--
-- 點解會中：
--   ActionButton1 係【受保護框架】。Dominos 隱藏佢之後，
--   MainActionBar 因為 keepEvents = true 而【繼續收事件】，
--   一收事件就跑 Update -> UpdateAction -> UpdatePressAndHoldAction，
--   入面會行 self:SetAttribute("pressAndHoldAction", ...)。
--   戰鬥中對受保護框架 SetAttribute -> 客戶端擋住 -> 歸咎 Dominos。
--
-- 呢啲掣根本已經隱形冇人用，改唔改 pressAndHoldAction 完全冇意義。
-- 所以：隱形嘅 -> 直接唔做；顯示緊嘅 -> 照原邏輯行。
-- 放喺 hider 入面做最啱，因為淨係呢度先知邊啲掣真係被隱藏咗。
local function TitanNeuterPressAndHold(button)
    if (button == nil) or (button.TitanPressAndHoldNeutered) then return end
    local orig = button.UpdatePressAndHoldAction
    if (type(orig) ~= "function") then return end
    button.UpdatePressAndHoldAction = function(self, ...)
        -- IsVisible() 連 parent 隱藏都測到，比 IsShown() 準
        if not self:IsVisible() then
            return
        end
        return orig(self, ...)
    end
    button.TitanPressAndHoldNeutered = true
end

local wipeActionButtons = {
    MultiBar5 = true,
    MultiBar6 = true,
    MultiBar7 = true,
    MultiBarBottomLeft = true,
    MultiBarBottomRight = true,
    MultiBarLeft = true,
    MultiBarRight = true
}

for _, frameName in ipairs(framesToHide) do
    local frame = _G[frameName]

    if frame then
        -- [titan7] 條本身都封咗（ActionButton1 係經 MainActionBar 觸發）
        TitanNeuterPressAndHold(frame)

        if not keepEvents[frameName] then
            frame:UnregisterAllEvents()
        end

        (frame.HideBase or frame.Hide)(frame)
        frame:SetParent(Addon.ShadowUIParent)

        if frame.actionButtons and type(frame.actionButtons) == "table" then
            for _, button in pairs(frame.actionButtons) do
                button:UnregisterAllEvents()
                button:SetAttributeNoHandler("statehidden", true)
                button:Hide()
                -- [titan7] 隱形掣唔使再理 pressAndHoldAction
                TitanNeuterPressAndHold(button)
            end

            if wipeActionButtons[frameName] then
                table.wipe(frame.actionButtons)
            end
        end
    else
        Addon:Printf('Could not find frame %q', frameName)
    end
end
