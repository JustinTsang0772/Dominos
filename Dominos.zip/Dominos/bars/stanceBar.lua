--------------------------------------------------------------------------------
-- Stance bar
-- Lets you move around the bar for displaying forms/stances/etc
--------------------------------------------------------------------------------

local AddonName, Addon = ...
local L = LibStub('AceLocale-3.0'):GetLocale(AddonName)

-- test to see if the player has a stance bar
-- not the best looking, but I also don't need to keep it after I do the check
if not ({
    DEATHKNIGHT = Addon:IsGameType('mists', 'cata', 'wrath'),
    DEMONHUNTER = false,
    DRUID = true,
    EVOKER = true,
    HUNTER = Addon:IsGameType('mists', 'cata'),
    MAGE = false,
    MONK = Addon:IsGameType('mists'),
    PALADIN = true,
    PRIEST = Addon:IsGameType('standard', 'mists', 'cata', 'wrath'),
    ROGUE = true,
    SHAMAN = false,
    WARLOCK = Addon:IsGameType('mists', 'cata', 'wrath'),
    WARRIOR = true,
})[UnitClassBase('player')] then
    return
end

--------------------------------------------------------------------------------
-- Button setup
--------------------------------------------------------------------------------

local StanceButtons = setmetatable({}, {
    __index = function(self, index)
        local button = CreateFrame('CheckButton', ('%sStanceButton%d'):format(AddonName, index), nil, 'StanceButtonTemplate', index)

        -- tag with the default stance button binding id
        button:SetAttribute("commandName", 'SHAPESHIFTBUTTON' .. index)

        -- turn off cooldown edges
        button.cooldown:SetDrawEdge(false)

        -- turn off constant usability updates
        button:SetScript("OnUpdate", nil)

        -- register mouse clicks
        button:EnableMouseWheel(true)

        if button.SlotBackground then
            button.SlotBackground:Hide()
        end

        -- apply hooks for quick binding
        Addon.BindableButton:AddQuickBindingSupport(button)

        self[index] = button

        return button
    end
})

--------------------------------------------------------------------------------
-- Bar setup
--------------------------------------------------------------------------------

local DominosStanceBar = Addon:CreateClass('Frame', Addon.ButtonBar)

function DominosStanceBar:New()
    return DominosStanceBar.proto.New(self, 'class')
end

function DominosStanceBar:GetDisplayName()
    return L.ClassBarDisplayName
end

function DominosStanceBar:GetDefaults()
    return {
        point = 'CENTER',
        spacing = 2
    }
end

function DominosStanceBar:NumButtons()
    return GetNumShapeshiftForms() or 0
end

function DominosStanceBar:AcquireButton(index)
    return StanceButtons[index]
end

function DominosStanceBar:OnAttachButton(button, index)
    button.HotKey:SetAlpha(self:ShowingBindingText() and 1 or 0)
    button:SetShown(index <= (GetNumShapeshiftForms() or 0))

    Addon:GetModule('ButtonThemer'):Register(button, 'Class Bar')
    Addon:GetModule('Tooltips'):Register(button)
end

function DominosStanceBar:OnDetachButton(button)
    Addon:GetModule('ButtonThemer'):Unregister(button, 'Class Bar')
    Addon:GetModule('Tooltips'):Unregister(button)
end

function DominosStanceBar:UpdateActions()
	for index, button in pairs(self.buttons) do
        local texture, isActive, isCastable = GetShapeshiftFormInfo(index)

        button:SetAlpha(texture and 1 or 0)
        button.icon:SetTexture(texture)

        if isCastable then
            button.icon:SetVertexColor(1.0, 1.0, 1.0)
        else
            button.icon:SetVertexColor(0.4, 0.4, 0.4)
        end

        local start, duration, enable = GetShapeshiftFormCooldown(index)
        if enable and enable ~= 0 and start > 0 and duration > 0 then
            button.cooldown:SetCooldown(start, duration)
        else
            button.cooldown:Clear()
        end

        button:SetChecked(isActive and true)
    end
end

-- binding text
function DominosStanceBar:SetShowBindingText(show)
    show = show and true

    if show == Addon.db.profile.showBindingText then
        self.sets.showBindingText = nil
    else
        self.sets.showBindingText = show
    end

    for _, button in pairs(self.buttons) do
        button.HotKey:SetAlpha(show and 1 or 0)
    end
end

function DominosStanceBar:ShowingBindingText()
    local result = self.sets.showBindingText

    if result == nil then
        result = Addon.db.profile.showBindingText
    end

    return result
end

function DominosStanceBar:OnCreateMenu(menu)
    local L = LibStub('AceLocale-3.0'):GetLocale('Dominos-Config')

    local layoutPanel = menu:NewPanel(L.Layout)

    layoutPanel:NewCheckButton {
        name = L.ShowBindingText,
        get = function()
            return layoutPanel.owner:ShowingBindingText()
        end,
        set = function(_, enable)
            layoutPanel.owner:SetShowBindingText(enable)
        end
    }

    layoutPanel:AddLayoutOptions()

    menu:AddFadingPanel()
    menu:AddAdvancedPanel()
end

-- export
Addon.StanceBar = DominosStanceBar

--------------------------------------------------------------------------------
-- Module
--------------------------------------------------------------------------------

local StanceBarModule = Addon:NewModule('StanceBar', 'AceEvent-3.0')

function StanceBarModule:Load()
    self.bar = DominosStanceBar:New()

    self:RegisterEvent("PLAYER_ENTERING_WORLD", 'UpdateNumForms')
    self:RegisterEvent("PLAYER_REGEN_ENABLED", 'UpdateNumForms')
    self:RegisterEvent("UPDATE_SHAPESHIFT_FORMS", 'UpdateNumForms')
    self:RegisterEvent("UPDATE_SHAPESHIFT_FORM", 'UpdateStanceButtons')
    self:RegisterEvent("UPDATE_SHAPESHIFT_USABLE", 'UpdateStanceButtons')
    self:RegisterEvent("UPDATE_SHAPESHIFT_COOLDOWN", 'UpdateStanceButtons')
end

function StanceBarModule:Unload()
    self:UnregisterAllEvents()

    if self.bar then
        self.bar:Free()
        self.bar = nil
    end
end

-- ---------------------------------------------------------------------------
-- 38002 (Titan / Wrath 混血客户端) 相容修复 —— by Yuanbao
--
-- 原版做咗三件事：
--     (StanceBar.HideBase or StanceBar.Hide)(StanceBar)
--     StanceBar:SetParent(Addon.ShadowUIParent)   <== 元凶
--     StanceBar:UnregisterAllEvents()
--
-- StanceBar 系暴雪「保护框架」(protected frame)，必须留喺安全嘅 parent 链入面。
-- 一旦俾插件 SetParent 去一个插件自建 frame（ShadowUIParent = Dominos 自己整
-- 嘅唔安全 frame），StanceBar 就变 insecure。之后：
--     ActionBarController -> StanceBar:Update() -> SetShown()
--     -> ShowOverride() -> UpdateVisibility() -> SetShownBase()
-- 会被暴雪拦低，报 ADDON_ACTION_BLOCKED 并赖 Dominos。
--
-- 点解正式服冇事、38002 有事：
--   真 Wrath (30405) 冇 `StanceBar` 呢个全域变数（得 StanceBarFrame），
--   所以呢段 if StanceBar then 根本唔会入。
--   38002 底层用咗新版 ActionBar 代码，`StanceBar` 存在 -> 呢段会跑 -> 中招。
--
-- 修复原则：完全唔碰 parent、唔取消事件、唔 call 保护函数（Hide/Show/SetShown）。
-- 净做「睇唔到、撳唔到」—— alpha / EnableMouse 唔系保护属性，唔会令框架变 insecure。
-- ---------------------------------------------------------------------------
function StanceBarModule:OnFirstLoad()
    if not StanceBar then return end

    -- 只改非保护属性：透明度 + 关闭滑鼠
    pcall(function()
        StanceBar:SetAlpha(0)
        StanceBar:EnableMouse(false)
    end)

    -- 按钮都一样：净改透明度同滑鼠，唔改 parent、唔改 statehidden、唔 Hide
    pcall(function()
        local buttons = StanceBar.actionButtons
        if type(buttons) ~= 'table' then return end

        for _, button in pairs(buttons) do
            if button then
                button:SetAlpha(0)
                button:EnableMouse(false)
            end
        end
    end)
end

function StanceBarModule:UpdateNumForms()
    if not InCombatLockdown() then
        self.bar:UpdateNumButtons()
    end

    self:UpdateStanceButtons()
end

StanceBarModule.UpdateStanceButtons = Addon:Debounce(function(self)
    local bar = self.bar
    if bar then
        bar:UpdateActions()
    end
end, 0.01, StanceBarModule)